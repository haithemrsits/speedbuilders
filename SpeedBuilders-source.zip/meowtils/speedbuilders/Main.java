package meowtils.speedbuilders;

import meowtils.speedbuilders.SpeedBuilders;
import wtf.tatp.meowtils.extension.Extension;
import wtf.tatp.meowtils.gui.Module;

public class Main {
    public static void init() {
        Extension.registerModule((Module)new SpeedBuilders());
    }
}

