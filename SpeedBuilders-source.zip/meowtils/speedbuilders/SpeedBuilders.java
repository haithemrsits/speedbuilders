package meowtils.speedbuilders;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockButton;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockDaylightDetector;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockLever;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.BlockQuartz;
import net.minecraft.block.BlockRailBase;
import net.minecraft.block.BlockSign;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.BlockTorch;
import net.minecraft.block.BlockTrapDoor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.event.HoverEvent;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemDoor;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import org.lwjgl.input.Mouse;
import wtf.tatp.meowtils.Meowtils;
import wtf.tatp.meowtils.config.Config;
import wtf.tatp.meowtils.event.ChatReceivedEvent;
import wtf.tatp.meowtils.event.ClientTickEvent;
import wtf.tatp.meowtils.event.MouseInputEvent;
import wtf.tatp.meowtils.event.RenderGameOverlayEvent;
import wtf.tatp.meowtils.event.RenderWorldLastEvent;
import wtf.tatp.meowtils.event.api.EventTarget;
import wtf.tatp.meowtils.extension.Extension;
import wtf.tatp.meowtils.gui.Module;
import wtf.tatp.meowtils.gui.hudeditor.HudEntry;
import wtf.tatp.meowtils.util.Render;

public class SpeedBuilders
extends Extension {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final String MODE_TOGGLE = "Toggle (Middle)";
    private static final String MODE_HOLD = "Hold (Right)";
    private static final String SWAP_DISABLED = "Disabled";
    private static final String RENDER_ALL = "All";
    private static final String RENDER_HOLDING = "Holding";
    private static final String RENDER_PLACEABLE = "Placeable";
    private static final String STATS_HOVER = "Hover";
    @Config
    public boolean enabled = false;
    @Config
    public int key = 0;
    @Config
    public String activation = "Toggle (Middle)";
    @Config
    public String autoPlace = "Hover";
    @Config
    public double placeDelay = 1.0;
    @Config
    public String autoSwap = "Disabled";
    @Config
    public String renderBlocks = "Holding";
    @Config
    public String showStats = "Chat";
    @Config
    public boolean infoHud = true;
    @Config
    public boolean saveStats = true;
    @Config
    public boolean showTime = true;
    @Config
    public boolean strictPlacements = true;
    @Config
    public int infoPosX = 4;
    @Config
    public int infoPosY = 4;
    private int ticks;
    private int state;
    private int lastState;
    private int judgedAt;
    private BlockPos center;
    private Map<BlockPos, IBlockState> build;
    private List<BlockPos> waiting;
    private String status;
    private String theme;
    private String themeKey;
    private int timeTicks;
    private long timeFadeAt;
    private ItemStack lastItem;
    private Map<BlockPos, Integer> highlights;
    private Map<IBlockState, Integer> missing;
    private boolean auto;
    private int lastPlaceTick;
    private int placeWait;
    private boolean halfTick = true;
    private int totalBlocks;
    private int blocksLeft;
    private final Map<String, Double> bestTimes = new HashMap<String, Double>();
    private final File timesFile;

    public SpeedBuilders() {
        super("Speed Builders", "Meowtils");
        this.timesFile = new File(SpeedBuilders.mc.mcDataDir, "speedbuilders.txt");
        this.tooltip("Hypixel Speed Builders helper: build overlay, auto swap and hover auto place.");
        this.toggle("Enabled", "enabled");
        this.mode("Activation", Arrays.asList(MODE_TOGGLE, MODE_HOLD), "activation");
        this.mode("Auto place", Arrays.asList(SWAP_DISABLED, STATS_HOVER), "autoPlace");
        this.slider("Place delay", 0.0, 10.0, 0.5, " ticks", "placeDelay", Double.TYPE);
        this.mode("Auto swap", Arrays.asList(SWAP_DISABLED, "Incremental", STATS_HOVER), "autoSwap");
        this.mode("Render blocks", Arrays.asList(SWAP_DISABLED, RENDER_ALL, RENDER_HOLDING, RENDER_PLACEABLE), "renderBlocks");
        this.mode("Show stats", Arrays.asList(SWAP_DISABLED, "Chat", STATS_HOVER), "showStats");
        this.toggle("Info HUD", "infoHud");
        this.toggle("Save stats", "saveStats");
        this.toggle("Show time", "showTime");
        this.toggle("Strict placements", "strictPlacements");
        this.bind("Keybind", "key");
        this.loadTimes();
    }

    public void onEnable() {
        this.auto = !MODE_HOLD.equals(this.activation);
    }

    public void onDisable() {
        this.resetState();
    }

    public void onReset() {
        this.resetState();
    }

    private void resetState() {
        this.timeTicks = 0;
        this.placeWait = 0;
        this.lastPlaceTick = 0;
        this.judgedAt = 0;
        this.lastState = 0;
        this.state = 0;
        this.ticks = 0;
        this.timeFadeAt = 0L;
        this.status = null;
        this.lastItem = null;
        this.center = null;
        this.build = null;
        this.missing = null;
        this.highlights = null;
        this.waiting = null;
    }

    public List<HudEntry> hudEditor() {
        return Arrays.asList(new HudEntry("Info", (Module)this, "infoPosX", "infoPosY", () -> new int[]{Math.max(90, SpeedBuilders.mc.fontRendererObj.getStringWidth("Speed Builders  Progress: 999/999 100%")), 60}));
    }

    @EventTarget
    public void onClientTick(ClientTickEvent event) {
        if (event.getPhase() != ClientTickEvent.Phase.POST) {
            return;
        }
        if (!this.enabled || SpeedBuilders.mc.thePlayer == null || SpeedBuilders.mc.theWorld == null) {
            return;
        }
        try {
            ++this.ticks;
            this.state = SpeedBuilders.buildBattleState();
            if (this.state == 0) {
                return;
            }
            if (MODE_HOLD.equals(this.activation)) {
                this.auto = Mouse.isButtonDown((int)1);
            }
            if (this.state == 1 || this.state == 2 || this.state == 5) {
                this.build = null;
                this.waiting = null;
            }
            switch (this.state) {
                case 1: {
                    this.status = "Queueing";
                    break;
                }
                case 2: {
                    this.status = "Waiting";
                    if (this.ticks % 2 != 0 || this.center != null) break;
                    this.findCenter();
                    break;
                }
                case 3: {
                    this.tickShowing();
                    break;
                }
                case 4: {
                    this.tickBuilding();
                    break;
                }
                case 5: {
                    this.status = "Judging";
                    this.judgedAt = this.ticks;
                    break;
                }
            }
            this.lastState = this.state;
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @EventTarget
    public void onMouse(MouseInputEvent event) {
        if (!this.enabled || this.state == 0) {
            return;
        }
        if (event.getAction() == MouseInputEvent.Action.MIDDLE_CLICK && MODE_TOGGLE.equals(this.activation)) {
            this.auto = !this.auto;
            return;
        }
        if (event.getAction() == MouseInputEvent.Action.RIGHT_CLICK && MODE_HOLD.equals(this.activation) && this.state == 4 && this.missing != null && !this.missing.isEmpty()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (this.state != 4 || SWAP_DISABLED.equals(this.renderBlocks) || this.highlights == null || SpeedBuilders.mc.thePlayer == null || SpeedBuilders.mc.theWorld == null) {
            return;
        }
        for (Map.Entry<BlockPos, Integer> entry : this.highlights.entrySet()) {
            this.renderBlock(entry.getKey(), entry.getValue());
        }
    }

    @EventTarget
    public void onRenderGameOverlay(RenderGameOverlayEvent event) {
        if (!this.enabled || this.state == 0 || SpeedBuilders.mc.thePlayer == null) {
            return;
        }
        if (SpeedBuilders.mc.currentScreen != null) {
            return;
        }
        if (this.infoHud) {
            this.renderInfoHud();
        }
        if (this.showTime) {
            this.renderTimer();
        }
    }

    @EventTarget
    public void onChatReceived(ChatReceivedEvent event) {
        if (!this.enabled || event.getType() != 0) {
            return;
        }
        if (this.state != 4 || SpeedBuilders.mc.thePlayer == null) {
            return;
        }
        IChatComponent component = event.getComponent();
        String text = component.getUnformattedText();
        if (text == null || !text.startsWith(SpeedBuilders.mc.thePlayer.getName())) {
            return;
        }
        double time = SpeedBuilders.parseCompletionTime(text);
        if (Double.isNaN(time)) {
            return;
        }
        this.timeTicks = -this.timeTicks;
        if (this.themeKey == null) {
            return;
        }
        Double best = this.bestTimes.get(this.themeKey);
        if (this.saveStats && (best == null || time < best)) {
            this.bestTimes.put(this.themeKey, time);
            this.saveTimes();
        }
        if (STATS_HOVER.equals(this.showStats)) {
            String line = SpeedBuilders.bestLine(best, time);
            String blocks = "&7blocks: &b" + this.totalBlocks + " &7~ &b" + SpeedBuilders.round((double)this.totalBlocks / time, 1) + " &7bps";
            ChatStyle style = new ChatStyle();
            style.setChatHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (IChatComponent)new ChatComponentText(SpeedBuilders.color("&7theme: &b" + this.theme + "\n" + line + "\n" + blocks))));
            component.setChatStyle(style);
        } else if (!SWAP_DISABLED.equals(this.showStats)) {
            Meowtils.addMessage((String)SpeedBuilders.color(SpeedBuilders.bestLine(best, time)));
            Meowtils.addMessage((String)SpeedBuilders.color("&7blocks: &b" + this.totalBlocks + " &7~ &b" + SpeedBuilders.round((double)this.totalBlocks / time, 1) + " &7bps"));
        }
    }

    private void tickShowing() {
        List<String> lines;
        this.status = "Showing";
        if (this.ticks - this.judgedAt < 10 || this.ticks % 5 != 0) {
            return;
        }
        if (this.center == null) {
            this.findCenter();
            if (this.center == null) {
                return;
            }
        }
        if (this.build == null) {
            this.build = new HashMap<BlockPos, IBlockState>();
        }
        if ((lines = SpeedBuilders.sidebar()) != null && lines.size() > 6) {
            for (String s : lines) {
                if (s.startsWith("Theme: ")) {
                    this.theme = SpeedBuilders.strip(s).replace("Theme: ", "");
                    continue;
                }
                if (!s.startsWith("Difficulty: ")) continue;
                this.themeKey = this.theme + "-" + SpeedBuilders.strip(s).replace("Difficulty: ", "");
                break;
            }
        }
        for (int y = 1; y <= 13; ++y) {
            for (int x = -3; x <= 3; ++x) {
                for (int z = -3; z <= 3; ++z) {
                    BlockPos pos = new BlockPos(this.center.getX() + x, this.center.getY() + y, this.center.getZ() + z);
                    IBlockState stored = this.build.get(pos);
                    if (stored != null && stored.getBlock() != Blocks.air) continue;
                    this.build.put(pos, SpeedBuilders.getState(pos));
                }
            }
        }
    }

    private void tickBuilding() {
        this.status = "Building";
        if (this.lastState == 3) {
            this.timeTicks = 1;
        } else if (this.timeTicks > 0) {
            ++this.timeTicks;
        }
        if (this.build == null) {
            return;
        }
        if (this.waiting == null) {
            this.waiting = new ArrayList<BlockPos>();
            this.lastItem = null;
        }
        this.highlights = new HashMap<BlockPos, Integer>();
        this.missing = new HashMap<IBlockState, Integer>();
        ItemStack held = SpeedBuilders.mc.thePlayer.getHeldItem();
        for (Map.Entry<BlockPos, IBlockState> entry : this.build.entrySet()) {
            boolean halfOfDouble;
            BlockPos pos = entry.getKey();
            IBlockState current = SpeedBuilders.getState(pos);
            IBlockState wanted = entry.getValue();
            Block now = current.getBlock();
            Block block = wanted.getBlock();
            if (block == Blocks.air) {
                if (now == block) continue;
                this.highlights.put(pos, 3);
                continue;
            }
            boolean bl = halfOfDouble = now instanceof BlockSlab && !now.isFullBlock() && block instanceof BlockSlab && block.isFullBlock() && now == SpeedBuilders.singleSlab(block) && now.getMetaFromState(current) == block.getMetaFromState(wanted);
            if (now == Blocks.air || halfOfDouble) {
                boolean placeable = this.canPlaceAt(pos, wanted);
                if (placeable) {
                    this.missing.merge(wanted, 1, Integer::sum);
                }
                if (RENDER_ALL.equals(this.renderBlocks)) {
                    this.highlights.put(pos, placeable ? 1 : 2);
                    continue;
                }
                if (!RENDER_HOLDING.equals(this.renderBlocks) && (!placeable || !RENDER_PLACEABLE.equals(this.renderBlocks))) continue;
                if (held == null) {
                    this.highlights.put(pos, 0);
                    continue;
                }
                if (!SpeedBuilders.matches(held, wanted)) continue;
                this.highlights.put(pos, placeable ? 1 : 2);
                continue;
            }
            if (now != block) {
                this.highlights.put(pos, 3);
                continue;
            }
            if (now.getMetaFromState(current) == block.getMetaFromState(wanted) || block == Blocks.leaves || block == Blocks.double_plant || block instanceof BlockRailBase) continue;
            this.highlights.put(pos, 4);
            if (this.strictPlacements) continue;
            boolean lenient = false;
            if (block == Blocks.lever || block instanceof BlockButton || block instanceof BlockDaylightDetector || block == Blocks.flowing_lava) {
                lenient = true;
            } else if (block instanceof BlockStairs) {
                EnumFacing f2;
                EnumFacing f1;
                BlockStairs.EnumHalf h2;
                BlockStairs.EnumHalf h1 = (BlockStairs.EnumHalf)current.getValue((IProperty)BlockStairs.HALF);
                if (h1 == (h2 = (BlockStairs.EnumHalf)wanted.getValue((IProperty)BlockStairs.HALF)) && ((f1 = (EnumFacing)current.getValue((IProperty)BlockStairs.FACING)) == (f2 = (EnumFacing)wanted.getValue((IProperty)BlockStairs.FACING)) || f1 == f2.rotateY() || f1 == f2.rotateYCCW())) {
                    lenient = true;
                }
            } else if (block instanceof BlockDoor && wanted.getValue((IProperty)BlockDoor.HALF) == BlockDoor.EnumDoorHalf.UPPER) {
                lenient = true;
            }
            if (!lenient) continue;
            this.highlights.remove(pos);
        }
        ArrayList<Map.Entry<IBlockState, Integer>> sorted = new ArrayList<Map.Entry<IBlockState, Integer>>(this.missing.entrySet());
        sorted.sort(SpeedBuilders::compareMissing);
        if (this.auto) {
            if (!SWAP_DISABLED.equals(this.autoSwap)) {
                int slot = this.pickSlot(held, sorted);
                if (slot >= 0) {
                    SpeedBuilders.mc.thePlayer.inventory.currentItem = slot;
                    this.lastItem = held;
                    held = SpeedBuilders.mc.thePlayer.getHeldItem();
                } else {
                    this.lastItem = held;
                }
            }
            this.tryAutoPlace(held);
        }
        int count = 0;
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i);
            if (stack == null) continue;
            count += stack.stackSize;
        }
        if (this.lastState == 3) {
            this.totalBlocks = count;
        } else {
            this.blocksLeft = count;
        }
    }

    private void tryAutoPlace(ItemStack held) {
        boolean canPlace;
        if (!STATS_HOVER.equals(this.autoPlace) || !SpeedBuilders.noUseOrDig() || this.ticks - this.lastPlaceTick < this.placeWait) {
            return;
        }
        MovingObjectPosition hit = SpeedBuilders.mc.objectMouseOver;
        if (hit == null || hit.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
            return;
        }
        BlockPos pos = hit.getBlockPos().offset(hit.sideHit);
        if (!SpeedBuilders.isPassable(pos) || SpeedBuilders.opensOnClick(hit.getBlockPos())) {
            return;
        }
        IBlockState target = this.build.get(pos);
        if (target == null || !SpeedBuilders.matches(held, target) || SpeedBuilders.is(held, Items.water_bucket) || SpeedBuilders.is(held, Items.lava_bucket)) {
            return;
        }
        boolean bl = canPlace = !(held.getItem() instanceof ItemBlock) || SpeedBuilders.canPlaceItem(hit, held);
        if (this.waiting.contains(pos)) {
            if (canPlace) {
                this.waiting.remove(pos);
            }
            return;
        }
        if (!canPlace) {
            this.waiting.add(pos);
            return;
        }
        if (!this.placesAs(target, hit, held)) {
            return;
        }
        if (SpeedBuilders.mc.playerController.onPlayerRightClick(SpeedBuilders.mc.thePlayer, SpeedBuilders.mc.theWorld, held, hit.getBlockPos(), hit.sideHit, hit.hitVec)) {
            SpeedBuilders.swing();
            this.afterPlace();
        }
    }

    private void afterPlace() {
        SpeedBuilders.clearEmptyStacks();
        this.lastPlaceTick = this.ticks;
        this.placeWait = (int)Math.floor(this.placeDelay) + 1;
        if (this.placeDelay % 1.0 == 0.5) {
            if (this.halfTick) {
                ++this.placeWait;
            }
            this.halfTick = !this.halfTick;
        }
    }

    private void findCenter() {
        for (int x = -5; x <= 5; ++x) {
            for (int z = -5; z <= 5; ++z) {
                BlockPos pos = new BlockPos(SpeedBuilders.mc.thePlayer.posX + (double)x, 71.0, SpeedBuilders.mc.thePlayer.posZ + (double)z);
                IBlockState state = SpeedBuilders.getState(pos);
                if (state.getBlock() != Blocks.quartz_block || state.getBlock().getMetaFromState(state) != 1) continue;
                boolean grass = true;
                for (EnumFacing facing : EnumFacing.HORIZONTALS) {
                    if (SpeedBuilders.getBlock(pos.offset(facing)) == Blocks.grass) continue;
                    grass = false;
                    break;
                }
                if (!grass) continue;
                this.center = pos;
                return;
            }
        }
    }

    private static int buildBattleState() {
        List<String> lines = SpeedBuilders.sidebar();
        if (!SpeedBuilders.onHypixel() || lines == null || lines.size() <= 6 || !SpeedBuilders.strip(lines.get(0)).contains("BUILD BATTLE")) {
            return 0;
        }
        boolean startsIn = false;
        boolean timeLeft = false;
        boolean theme = false;
        boolean judging = false;
        for (String line : lines) {
            if (line.contains("Mode:") && line.contains("Speed Bu")) {
                return 1;
            }
            if (line.contains("Starts In:")) {
                startsIn = true;
                continue;
            }
            if (line.contains("Time Left:")) {
                timeLeft = true;
                continue;
            }
            if (line.contains("Judging:")) {
                judging = true;
                continue;
            }
            if (line.contains("Theme:")) {
                theme = true;
                continue;
            }
            if (!line.contains("Perfect Builds:")) continue;
            if (theme) {
                if (startsIn) {
                    boolean items = false;
                    for (int i = 0; i < 9; ++i) {
                        if (SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i) == null) continue;
                        items = true;
                        break;
                    }
                    return items ? 4 : 3;
                }
                if (timeLeft) {
                    return 4;
                }
                if (!judging) continue;
                return 5;
            }
            return 2;
        }
        return 0;
    }

    private static boolean onHypixel() {
        if (SpeedBuilders.mc.thePlayer == null || SpeedBuilders.mc.theWorld == null || mc.isSingleplayer()) {
            return false;
        }
        if (mc.getCurrentServerData() == null) {
            return false;
        }
        String ip = SpeedBuilders.mc.getCurrentServerData().serverIP;
        return ip != null && ip.toLowerCase().contains("hypixel");
    }

    private static List<String> sidebar() {
        if (SpeedBuilders.mc.theWorld == null) {
            return null;
        }
        Scoreboard scoreboard = SpeedBuilders.mc.theWorld.getScoreboard();
        if (scoreboard == null) {
            return null;
        }
        ScoreObjective objective = scoreboard.getObjectiveInDisplaySlot(1);
        if (objective == null) {
            return null;
        }
        ArrayList scores = new ArrayList(scoreboard.getSortedScores(objective));
        ArrayList<String> out = new ArrayList<String>(10);
        out.add(objective.getDisplayName());
        int n = 0;
        for (int i = scores.size() - 1; i >= 0 && n < 15; --i) {
            String name;
            Score score = (Score)scores.get(i);
            if (score == null || (name = score.getPlayerName()) == null || name.startsWith("#")) continue;
            ScorePlayerTeam team = scoreboard.getPlayersTeam(name);
            out.add(ScorePlayerTeam.formatPlayerName((Team)team, (String)name));
            ++n;
        }
        return out;
    }

    private int pickSlot(ItemStack held, List<Map.Entry<IBlockState, Integer>> sorted) {
        int i;
        if (sorted.isEmpty() && held == null) {
            for (int i2 = 0; i2 < 9; ++i2) {
                if (SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i2) == null) continue;
                return i2;
            }
            return -1;
        }
        if (STATS_HOVER.equals(this.autoSwap) && SpeedBuilders.mc.objectMouseOver != null && SpeedBuilders.mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            IBlockState expected;
            BlockPos pos = SpeedBuilders.mc.objectMouseOver.getBlockPos().offset(SpeedBuilders.mc.objectMouseOver.sideHit);
            IBlockState iBlockState = expected = this.build != null ? this.build.get(pos) : null;
            if (expected != null) {
                for (i = 0; i < 9; ++i) {
                    if (!SpeedBuilders.matches(SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i), expected)) continue;
                    return i;
                }
            }
        }
        if (this.lastState == 4 && held != null) {
            for (Map.Entry<IBlockState, Integer> entry : sorted) {
                if (!SpeedBuilders.matches(held, entry.getKey())) continue;
                return -1;
            }
        }
        if (this.lastItem != null && held == null) {
            for (int i3 = 0; i3 < 9; ++i3) {
                ItemStack stack = SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i3);
                if (!SpeedBuilders.sameItem(this.lastItem, stack) || this.lastItem.getItemDamage() != stack.getItemDamage()) continue;
                return i3;
            }
        }
        for (Map.Entry<IBlockState, Integer> entry : sorted) {
            for (i = 0; i < 9; ++i) {
                if (!SpeedBuilders.matches(SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i), entry.getKey())) continue;
                return i;
            }
        }
        return -1;
    }

    private static boolean matches(ItemStack stack, IBlockState state) {
        try {
            boolean byMeta;
            ItemBlock itemBlock = SpeedBuilders.isBlock(stack) ? (ItemBlock)stack.getItem() : null;
            Block block = state.getBlock();
            if (itemBlock == null) {
                if (stack != null) {
                    if (block == Blocks.bed) {
                        return SpeedBuilders.is(stack, Items.bed);
                    }
                    if (block == Blocks.brewing_stand) {
                        return SpeedBuilders.is(stack, Items.brewing_stand);
                    }
                    if (block == Blocks.cauldron) {
                        return SpeedBuilders.is(stack, Items.cauldron);
                    }
                    if (block == Blocks.flower_pot) {
                        return SpeedBuilders.is(stack, Items.flower_pot);
                    }
                    if (block == Blocks.skull) {
                        return SpeedBuilders.is(stack, Items.skull);
                    }
                    if (block == Blocks.flowing_water || block == Blocks.water) {
                        return SpeedBuilders.is(stack, Items.water_bucket);
                    }
                    if (block == Blocks.lava || block == Blocks.flowing_lava) {
                        return SpeedBuilders.is(stack, Items.lava_bucket);
                    }
                    if (block instanceof BlockSign) {
                        return SpeedBuilders.is(stack, Items.sign);
                    }
                    if (block instanceof BlockDoor) {
                        return stack.getItem() instanceof ItemDoor;
                    }
                }
                return false;
            }
            Block placed = itemBlock.getBlock();
            if (!(placed == block || placed instanceof BlockSlab && block instanceof BlockSlab)) {
                return false;
            }
            boolean bl = byMeta = block == Blocks.wool || block == Blocks.stained_hardened_clay || block == Blocks.planks || block == Blocks.stained_glass || block == Blocks.stained_glass_pane || block == Blocks.stone || block instanceof BlockSlab;
            if (!byMeta) {
                return true;
            }
            int meta = stack.getItemDamage();
            int wantedMeta = block.getMetaFromState(state);
            if (block instanceof BlockSlab) {
                meta &= 7;
                wantedMeta &= 7;
            }
            return meta == wantedMeta;
        }
        catch (Exception ignored) {
            return false;
        }
    }

    private boolean canPlaceAt(BlockPos pos, IBlockState state) {
        try {
            EnumFacing facing;
            BlockSlab.EnumBlockHalf half;
            EnumSet<EnumFacing> sides = EnumSet.allOf(EnumFacing.class);
            Block block = state.getBlock();
            if (block instanceof BlockSlab) {
                if (block.isFullBlock()) {
                    Block there = SpeedBuilders.getBlock(pos);
                    if (there instanceof BlockSlab && !there.isFullBlock()) {
                        return true;
                    }
                } else {
                    half = (BlockSlab.EnumBlockHalf)state.getValue((IProperty)BlockSlab.HALF);
                    sides.remove(half == BlockSlab.EnumBlockHalf.TOP ? EnumFacing.DOWN : EnumFacing.UP);
                }
            } else if (block instanceof BlockStairs) {
                half = (BlockStairs.EnumHalf)state.getValue((IProperty)BlockStairs.HALF);
                if (this.strictPlacements) {
                    sides.clear();
                    sides.add(half == BlockStairs.EnumHalf.TOP ? EnumFacing.UP : EnumFacing.DOWN);
                    sides.add((EnumFacing)state.getValue((IProperty)BlockStairs.FACING));
                } else {
                    sides.remove(half == BlockStairs.EnumHalf.TOP ? EnumFacing.DOWN : EnumFacing.UP);
                }
            } else if (block instanceof BlockTorch) {
                facing = (EnumFacing)state.getValue((IProperty)BlockTorch.FACING);
                sides.clear();
                sides.add(facing.getOpposite());
            } else if (block instanceof BlockButton) {
                if (this.strictPlacements) {
                    facing = (EnumFacing)state.getValue((IProperty)BlockButton.FACING);
                    sides.clear();
                    sides.add(facing.getOpposite());
                }
            } else if (block instanceof BlockTrapDoor) {
                facing = (EnumFacing)state.getValue((IProperty)BlockTrapDoor.FACING);
                sides.clear();
                sides.add(facing.getOpposite());
            } else if (block instanceof BlockRailBase) {
                sides.clear();
                sides.add(EnumFacing.DOWN);
            }
            for (EnumFacing facing2 : sides) {
                IBlockState other;
                BlockPos p = pos.offset(facing2);
                if (SpeedBuilders.isReplaceable(p)) continue;
                if (block instanceof BlockSlab && !block.isFullBlock() && (other = SpeedBuilders.getState(p)).getBlock() instanceof BlockSlab && !other.getBlock().isFullBlock()) {
                    BlockSlab.EnumBlockHalf h = (BlockSlab.EnumBlockHalf)other.getValue((IProperty)BlockSlab.HALF);
                    BlockSlab.EnumBlockHalf mine = (BlockSlab.EnumBlockHalf)state.getValue((IProperty)BlockSlab.HALF);
                    if (facing2 == EnumFacing.UP) {
                        if (h != BlockSlab.EnumBlockHalf.BOTTOM) continue;
                    } else if (facing2 == EnumFacing.DOWN) {
                        if (h != BlockSlab.EnumBlockHalf.TOP) continue;
                    } else if (h != mine) continue;
                }
                return true;
            }
            return false;
        }
        catch (Exception ignored) {
            return false;
        }
    }

    private boolean placesAs(IBlockState wanted, MovingObjectPosition hit, ItemStack held) {
        Block block = wanted.getBlock();
        if (block == Blocks.double_plant || block instanceof BlockRailBase) {
            return true;
        }
        if (!this.strictPlacements && (block == Blocks.lever || block instanceof BlockButton)) {
            return true;
        }
        IBlockState result = block.getDefaultState();
        Collection properties = result.getPropertyNames();
        block25: for (IProperty property : properties) {
            String name = property.getName();
            int which = -1;
            switch (name) {
                case "facing": {
                    which = 0;
                    break;
                }
                case "axis": {
                    which = 1;
                    break;
                }
                case "half": {
                    which = 2;
                    break;
                }
                case "variant": {
                    which = 3;
                    break;
                }
            }
            switch (which) {
                case 0: {
                    EnumFacing facing = null;
                    if (!(block instanceof BlockStairs)) {
                        boolean piston;
                        boolean bl = piston = block == Blocks.dispenser || block == Blocks.dropper || block instanceof BlockPistonBase;
                        if (piston) {
                            facing = BlockPistonBase.getFacingFromEntity((World)SpeedBuilders.mc.theWorld, (BlockPos)hit.getBlockPos().offset(hit.sideHit), (EntityLivingBase)SpeedBuilders.mc.thePlayer);
                        } else if (block instanceof BlockTorch) {
                            if (hit.sideHit != EnumFacing.DOWN) {
                                facing = hit.sideHit;
                            } else {
                                BlockPos at = hit.getBlockPos().offset(hit.sideHit);
                                for (EnumFacing f : EnumFacing.HORIZONTALS) {
                                    if (!SpeedBuilders.mc.theWorld.isSideSolid(at.offset(f.getOpposite()), f, true)) continue;
                                    facing = f;
                                    at = null;
                                    break;
                                }
                                if (at != null) {
                                    return false;
                                }
                            }
                        } else if (block == Blocks.skull) {
                            if (hit.sideHit == EnumFacing.DOWN) {
                                return false;
                            }
                            if (hit.sideHit == EnumFacing.UP && wanted.getValue((IProperty)BlockSkull.FACING) == EnumFacing.UP) {
                                float yaw = (SpeedBuilders.mc.thePlayer.rotationYaw % 360.0f + 360.0f) % 360.0f;
                                boolean straight = false;
                                for (float a : new float[]{0.0f, 90.0f, 180.0f, 270.0f}) {
                                    float diff = Math.abs(yaw - a);
                                    if (!((diff = Math.min(diff, 360.0f - diff)) <= 8.0f)) continue;
                                    straight = true;
                                    break;
                                }
                                if (!straight) {
                                    return false;
                                }
                            }
                            facing = hit.sideHit;
                        } else if (block instanceof BlockButton) {
                            facing = hit.sideHit;
                        } else if (block == Blocks.tripwire_hook || block == Blocks.wall_sign) {
                            if (hit.sideHit == EnumFacing.UP || hit.sideHit == EnumFacing.DOWN) {
                                return false;
                            }
                            facing = hit.sideHit;
                        } else if (block == Blocks.hopper) {
                            if (hit.sideHit != EnumFacing.DOWN) {
                                facing = hit.sideHit.getOpposite();
                            }
                        } else if (block instanceof BlockFenceGate) {
                            facing = SpeedBuilders.mc.thePlayer.getHorizontalFacing();
                        } else {
                            if (block == Blocks.lever) {
                                BlockLever.EnumOrientation orientation;
                                EnumFacing player = SpeedBuilders.mc.thePlayer.getHorizontalFacing();
                                switch (SpeedBuilders.facingCase(hit.sideHit)) {
                                    case 1: {
                                        orientation = BlockLever.EnumOrientation.NORTH;
                                        break;
                                    }
                                    case 2: {
                                        orientation = BlockLever.EnumOrientation.SOUTH;
                                        break;
                                    }
                                    case 4: {
                                        orientation = BlockLever.EnumOrientation.EAST;
                                        break;
                                    }
                                    case 5: {
                                        orientation = player.getAxis() != EnumFacing.Axis.X ? BlockLever.EnumOrientation.UP_Z : BlockLever.EnumOrientation.UP_X;
                                        break;
                                    }
                                    case 6: {
                                        orientation = player.getAxis() != EnumFacing.Axis.X ? BlockLever.EnumOrientation.DOWN_Z : BlockLever.EnumOrientation.DOWN_X;
                                        break;
                                    }
                                    default: {
                                        orientation = BlockLever.EnumOrientation.WEST;
                                    }
                                }
                                result = SpeedBuilders.with(result, (IProperty)BlockLever.FACING, orientation);
                                continue block25;
                            }
                            facing = SpeedBuilders.mc.thePlayer.getHorizontalFacing().getOpposite();
                        }
                    } else {
                        EnumFacing f;
                        facing = SpeedBuilders.mc.thePlayer.getHorizontalFacing();
                        if (!(this.strictPlacements || (f = (EnumFacing)wanted.getValue((IProperty)BlockStairs.FACING)) != facing && f != facing.rotateY() && f != facing.rotateYCCW())) {
                            facing = f;
                        }
                    }
                    if (facing == null) continue block25;
                    result = SpeedBuilders.with(result, property, facing);
                    continue block25;
                }
                case 1: {
                    Comparable<?> axis = SpeedBuilders.axisFor(hit, property);
                    if (axis == null) continue block25;
                    result = SpeedBuilders.with(result, property, axis);
                    continue block25;
                }
                case 2: {
                    Comparable<?> half = SpeedBuilders.halfFor(hit, property);
                    if (half == null) continue block25;
                    result = SpeedBuilders.with(result, property, half);
                    continue block25;
                }
                case 3: {
                    result = SpeedBuilders.with(result, property, SpeedBuilders.variantFor(hit, property, wanted));
                    continue block25;
                }
            }
            result = SpeedBuilders.with(result, property, wanted.getValue(property));
        }
        return result.equals(wanted);
    }

    private static IBlockState with(IBlockState state, IProperty property, Object value) {
        if (property.getValueClass().isInstance(value)) {
            Comparable comparable = (Comparable)property.getValueClass().cast(value);
            return state.withProperty(property, comparable);
        }
        return state;
    }

    private static Comparable<?> axisFor(MovingObjectPosition hit, IProperty<?> property) {
        Class valueClass = property.getValueClass();
        if (valueClass == EnumFacing.Axis.class) {
            return hit.sideHit.getAxis();
        }
        if (valueClass == BlockLog.EnumAxis.class) {
            if (hit.sideHit == EnumFacing.UP || hit.sideHit == EnumFacing.DOWN) {
                return BlockLog.EnumAxis.Y;
            }
            switch (SpeedBuilders.facingCase(SpeedBuilders.mc.thePlayer.getHorizontalFacing())) {
                case 1: 
                case 2: {
                    return BlockLog.EnumAxis.Z;
                }
                case 3: 
                case 4: {
                    return BlockLog.EnumAxis.X;
                }
            }
        }
        return null;
    }

    private static Comparable<?> halfFor(MovingObjectPosition hit, IProperty<?> property) {
        float fraction = (float)(hit.hitVec.yCoord - (double)hit.getBlockPos().getY());
        if (property.getValueClass() == BlockStairs.EnumHalf.class) {
            if (hit.sideHit == EnumFacing.UP) {
                return BlockStairs.EnumHalf.BOTTOM;
            }
            if (hit.sideHit == EnumFacing.DOWN) {
                return BlockStairs.EnumHalf.TOP;
            }
            return fraction > 0.57f ? BlockStairs.EnumHalf.TOP : BlockStairs.EnumHalf.BOTTOM;
        }
        if (property.getValueClass() == BlockSlab.EnumBlockHalf.class) {
            if (hit.sideHit == EnumFacing.UP) {
                IBlockState state;
                if (SpeedBuilders.getBlock(hit.getBlockPos()) == Blocks.carpet && (state = SpeedBuilders.getState(hit.getBlockPos().offset(hit.sideHit))).getBlock() instanceof BlockSlab && !state.getBlock().isFullBlock()) {
                    BlockSlab.EnumBlockHalf h = (BlockSlab.EnumBlockHalf)state.getValue((IProperty)BlockSlab.HALF);
                    return h == BlockSlab.EnumBlockHalf.BOTTOM ? BlockSlab.EnumBlockHalf.TOP : BlockSlab.EnumBlockHalf.BOTTOM;
                }
                return (double)fraction == 0.5 ? BlockSlab.EnumBlockHalf.TOP : BlockSlab.EnumBlockHalf.BOTTOM;
            }
            if (hit.sideHit == EnumFacing.DOWN) {
                return (double)fraction == 0.5 ? BlockSlab.EnumBlockHalf.BOTTOM : BlockSlab.EnumBlockHalf.TOP;
            }
            return (double)fraction > 0.5 ? BlockSlab.EnumBlockHalf.TOP : BlockSlab.EnumBlockHalf.BOTTOM;
        }
        if (property.getValueClass() == BlockTrapDoor.DoorHalf.class) {
            return (double)fraction > 0.5 ? BlockTrapDoor.DoorHalf.TOP : BlockTrapDoor.DoorHalf.BOTTOM;
        }
        return null;
    }

    private static Comparable<?> variantFor(MovingObjectPosition hit, IProperty<?> property, IBlockState state) {
        BlockQuartz.EnumType type;
        if (state.getBlock() == Blocks.quartz_block && (type = (BlockQuartz.EnumType)state.getValue((IProperty)BlockQuartz.VARIANT)) != BlockQuartz.EnumType.DEFAULT && type != BlockQuartz.EnumType.CHISELED) {
            switch (SpeedBuilders.facingCase(hit.sideHit)) {
                case 1: 
                case 2: {
                    return BlockQuartz.EnumType.LINES_Z;
                }
                case 3: 
                case 4: {
                    return BlockQuartz.EnumType.LINES_X;
                }
                case 5: 
                case 6: {
                    return BlockQuartz.EnumType.LINES_Y;
                }
            }
        }
        return state.getValue(property);
    }

    private static int compareMissing(Map.Entry<IBlockState, Integer> a, Map.Entry<IBlockState, Integer> b) {
        boolean liquidA = a.getKey().getBlock() instanceof BlockLiquid;
        boolean liquidB = b.getKey().getBlock() instanceof BlockLiquid;
        if (liquidA && !liquidB) {
            return 1;
        }
        if (!liquidA && liquidB) {
            return -1;
        }
        int count = Integer.compare(b.getValue(), a.getValue());
        if (count != 0) {
            return count;
        }
        return a.getKey().toString().compareTo(b.getKey().toString());
    }

    private static int facingCase(EnumFacing facing) {
        switch (facing) {
            case DOWN: {
                return 6;
            }
            case UP: {
                return 5;
            }
            case NORTH: {
                return 1;
            }
            case SOUTH: {
                return 2;
            }
            case WEST: {
                return 3;
            }
        }
        return 4;
    }

    private void renderBlock(BlockPos pos, int kind) {
        Color color;
        IBlockState state;
        IBlockState iBlockState = state = this.build != null ? this.build.get(pos) : null;
        if (state == null) {
            return;
        }
        AxisAlignedBB box = new AxisAlignedBB((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), (double)pos.getX() + 1.0, (double)pos.getY() + 1.0, (double)pos.getZ() + 1.0);
        switch (kind) {
            case 0: {
                color = new Color(255, 170, 0, 59);
                break;
            }
            case 1: {
                color = new Color(85, 255, 85, 71);
                break;
            }
            case 2: {
                color = new Color(0, 170, 0, 59);
                break;
            }
            case 3: {
                color = new Color(255, 0, 0, 92);
                break;
            }
            default: {
                color = new Color(255, 128, 0, 92);
            }
        }
        Color outline = new Color(color.getRed(), color.getGreen(), color.getBlue(), 220);
        Render.drawBlockBox((AxisAlignedBB)box, (BlockPos)pos, (boolean)true, (Color)color, (boolean)true, (Color)outline, (double)0.002, (double)0.002, (double)0.002);
    }

    private void renderInfoHud() {
        FontRenderer font = SpeedBuilders.mc.fontRendererObj;
        int x = this.infoPosX;
        int y = this.infoPosY;
        font.drawStringWithShadow("Speed Builders", (float)x, (float)y, 0xFFAA00);
        font.drawStringWithShadow("Status: " + this.status, (float)x, (float)(y += 10), 0x55FFFF);
        y += 10;
        if (this.state >= 3) {
            if (this.themeKey != null) {
                Double best = this.bestTimes.get(this.themeKey);
                font.drawStringWithShadow("Theme: " + this.theme + (best != null ? " ~ " + SpeedBuilders.round(best, 1) + "s" : ""), (float)x, (float)y, 0x55FFFF);
                y += 10;
            }
            if (this.state >= 4 && this.totalBlocks > 0) {
                int done = this.totalBlocks - this.blocksLeft;
                double percent = SpeedBuilders.round((double)done / (double)this.totalBlocks * 100.0, 0);
                font.drawStringWithShadow("Progress: " + done + "/" + this.totalBlocks + " " + percent + "%", (float)x, (float)y, 0x55FFFF);
                y += 10;
            }
        }
        if (!SWAP_DISABLED.equals(this.autoPlace) || !SWAP_DISABLED.equals(this.autoSwap)) {
            font.drawStringWithShadow("Auto: " + (this.auto ? "ENABLED" : "DISABLED"), (float)x, (float)y, this.auto ? 0x55FF55 : 0xFF5555);
        }
    }

    private void renderTimer() {
        int alpha;
        long now = System.currentTimeMillis();
        if (this.state == 4 && this.timeTicks > 0) {
            this.timeFadeAt = -1L;
            alpha = 240;
        } else {
            long elapsed;
            if (this.timeFadeAt == -1L) {
                this.timeFadeAt = now;
            }
            int n = alpha = (elapsed = now - this.timeFadeAt) < 125L ? (int)(240.0f - (float)elapsed / 125.0f * 240.0f) : 0;
        }
        if (alpha <= 0) {
            return;
        }
        String text = "\u00a7b" + SpeedBuilders.round((double)Math.abs(this.timeTicks) / 20.0, 1) + "s";
        FontRenderer font = SpeedBuilders.mc.fontRendererObj;
        int width = font.getStringWidth(text);
        int screenWidth = new ScaledResolution(mc).getScaledWidth();
        int screenHeight = new ScaledResolution(mc).getScaledHeight();
        int posX = screenWidth / 2 - width / 2;
        int posY = screenHeight / 2 + 12;
        int color = Math.max(0, Math.min(255, alpha)) << 24 | 0xFFFFFF;
        font.drawString(text, (float)posX, (float)posY, color, true);
    }

    private void loadTimes() {
        block19: {
            this.bestTimes.clear();
            if (!this.timesFile.exists()) {
                return;
            }
            try {
                BufferedReader reader = new BufferedReader(new FileReader(this.timesFile));
                Throwable throwable = null;
                block13: while (true) {
                    try {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(": ");
                            if (parts.length != 2) continue;
                            try {
                                double value = Double.parseDouble(parts[1]);
                                if (!(value >= 0.0)) continue;
                                this.bestTimes.put(parts[0], value);
                                continue block13;
                            }
                            catch (NumberFormatException numberFormatException) {
                            }
                        }
                        break block19;
                    }
                    catch (Throwable throwable2) {
                        throwable = throwable2;
                        throw throwable2;
                    }
                }
                finally {
                    if (reader != null) {
                        if (throwable != null) {
                            try {
                                reader.close();
                            }
                            catch (Throwable throwable3) {
                                throwable.addSuppressed(throwable3);
                            }
                        } else {
                            reader.close();
                        }
                    }
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
    }

    private void saveTimes() {
        try {
            File parent = this.timesFile.getParentFile();
            if (parent != null) {
                parent.mkdirs();
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.timesFile));){
                for (Map.Entry<String, Double> entry : this.bestTimes.entrySet()) {
                    writer.write(entry.getKey() + ": " + entry.getValue());
                    writer.newLine();
                }
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    private static double parseCompletionTime(String message) {
        String[] parts;
        for (String part : parts = message.split(" ")) {
            if (!part.endsWith("s!") && !part.endsWith("s")) continue;
            String number = part.substring(0, part.length() - (part.endsWith("s!") ? 2 : 1));
            try {
                return Double.parseDouble(number);
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return Double.NaN;
    }

    private static String bestLine(Double best, double time) {
        if (best == null) {
            return "&7first attempt: &b" + SpeedBuilders.round(time, 1) + "s";
        }
        return "&7best: &b" + SpeedBuilders.round(best, 1) + "s &7(" + (time < best ? "&a-" + SpeedBuilders.round(best - time, 1) + "s &6PB&7)" : "&c+" + SpeedBuilders.round(time - best, 1) + "s&7)");
    }

    private static IBlockState getState(BlockPos pos) {
        return SpeedBuilders.mc.theWorld.getBlockState(pos);
    }

    private static Block getBlock(BlockPos pos) {
        return SpeedBuilders.getState(pos).getBlock();
    }

    private static boolean isBlock(ItemStack stack) {
        return stack != null && stack.getItem() instanceof ItemBlock;
    }

    private static boolean is(ItemStack stack, Item item) {
        return stack != null && stack.getItem() == item;
    }

    private static boolean sameItem(ItemStack a, ItemStack b) {
        Item itemA = a == null ? null : a.getItem();
        Item itemB = b == null ? null : b.getItem();
        return itemA == itemB;
    }

    private static boolean isReplaceable(BlockPos pos) {
        Block block = SpeedBuilders.getBlock(pos);
        return block == Blocks.air || block == Blocks.fire || block instanceof BlockLiquid || block.getMaterial().isReplaceable();
    }

    private static boolean isPassable(BlockPos pos) {
        if (SpeedBuilders.isReplaceable(pos)) {
            return true;
        }
        Block block = SpeedBuilders.getBlock(pos);
        if (!block.isFullBlock()) {
            return block instanceof BlockSlab || block == Blocks.snow_layer;
        }
        return false;
    }

    private static boolean opensOnClick(BlockPos pos) {
        return SpeedBuilders.mc.thePlayer != null && !SpeedBuilders.mc.thePlayer.isSneaking() && SpeedBuilders.isContainer(SpeedBuilders.getBlock(pos));
    }

    private static boolean isContainer(Block block) {
        return block instanceof BlockContainer || block == Blocks.crafting_table || block == Blocks.anvil;
    }

    private static boolean canPlaceItem(MovingObjectPosition hit, ItemStack stack) {
        return ((ItemBlock)stack.getItem()).canPlaceBlockOnSide((World)SpeedBuilders.mc.theWorld, hit.getBlockPos(), hit.sideHit, (EntityPlayer)SpeedBuilders.mc.thePlayer, stack);
    }

    private static Block singleSlab(Block block) {
        if (block == Blocks.double_stone_slab) {
            return Blocks.stone_slab;
        }
        if (block == Blocks.double_stone_slab2) {
            return Blocks.stone_slab2;
        }
        return Blocks.wooden_slab;
    }

    private static boolean noUseOrDig() {
        if (SpeedBuilders.mc.gameSettings.keyBindAttack.isKeyDown()) {
            return false;
        }
        return SpeedBuilders.mc.objectMouseOver == null || SpeedBuilders.mc.objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY;
    }

    private static void swing() {
        SpeedBuilders.mc.thePlayer.swingItem();
        mc.getItemRenderer().resetEquippedProgress();
    }

    private static void clearEmptyStacks() {
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = SpeedBuilders.mc.thePlayer.inventory.getStackInSlot(i);
            if (stack == null || stack.stackSize > 0) continue;
            SpeedBuilders.mc.thePlayer.inventory.setInventorySlotContents(i, null);
        }
    }

    private static String strip(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return EnumChatFormatting.getTextWithoutFormattingCodes((String)value);
    }

    private static String color(String value) {
        return value == null ? "" : value.replace("&", "\u00a7");
    }

    private static double round(double value, int places) {
        double factor = Math.pow(10.0, places);
        return (double)Math.round(value * factor) / factor;
    }
}

